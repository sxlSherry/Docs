
* [根目录](/)  
    * [jvm](/study/jvm/README)
        * [0_JVM——堆外内存](/study/jvm/JVM——堆外内存)
        * [1_JVM内存结构——运行时数据区](/study/jvm/JVM内存结构——运行时数据区)

